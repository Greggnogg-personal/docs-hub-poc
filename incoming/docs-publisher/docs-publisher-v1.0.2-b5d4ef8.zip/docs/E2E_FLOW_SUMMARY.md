# End-to-End Docs Publisher Flow — Summary

This document summarizes the full E2E flow for publishing documentation from a source repo to the docs hub, including security, monitoring, and validation.

---

## 1. Source Repo: netbox-docs-publisher
- **Edit docs** in `docs/` folder
- **Commit & push** to `main`
- **GitHub Actions** workflow triggers on docs changes

## 2. Publisher Workflow
- Validates `.docs-publisher.yaml` config
- Bundles docs and manifest
- Uses `DOCS_HUB_TOKEN` (fine-grained PAT, repo-scoped)
- Creates a branch and PR in the target docs-hub-poc repo
- Adds job summary with PR link and bundle details

## 3. Target Repo: docs-hub-poc
- PR appears in Pull Requests tab
- Ingest workflow triggers on PR with bundle in `incoming/**/*.zip`
- Validates and extracts bundle to `site/{slug}/{version}/`
- Runs smoke tests (manifest, docs folder)
- Uploads extracted site as artifact
- Adds job summary with extracted files and next steps

## 4. Monitoring & Validation
- All steps visible in Actions tab of both repos
- Job summaries show product, version, SHA, and file lists
- PR can be reviewed and merged by a human
- Security: PAT is fine-grained, repo-scoped, stored as secret
- Audit: All actions and PRs are logged in GitHub

## 5. Troubleshooting
- If no PR appears: check for "No changes detected" or errors in Actions logs
- If validation fails: review job summary and logs for manifest or extraction errors
- To force a PR: make any docs change and push

---

## Quick Checklist
- [x] PAT created and stored as secret
- [x] .docs-publisher.yaml targets correct owner/repo
- [x] Workflows present in both repos
- [x] Docs change triggers workflow
- [x] PR created in docs-hub-poc
- [x] Ingest workflow validates and extracts
- [x] Artifacts and summaries available for review

---

For more details, see `docs/E2E_SETUP.md`.
