# End-to-End Setup Guide — Production-Ready Credentials

This guide walks through setting up the complete docs-publisher → docs-hub-poc flow with production-grade security.

---

## Architecture Overview

```
┌─────────────────────────┐         ┌─────────────────────────┐
│  netbox-docs-publisher  │         │     docs-hub-poc        │
│  (source repo)          │         │   (destination hub)     │
├─────────────────────────┤         ├─────────────────────────┤
│ .docs-publisher.yaml    │         │ incoming/*.zip          │
│ docs/                   │  ────►  │ scripts/ingest_bundle.py│
│ .github/workflows/      │  PR     │ site/{slug}/{version}/  │
│   publish-docs.yml      │         │                         │
└─────────────────────────┘         └─────────────────────────┘
         │                                    ▲
         │ DOCS_HUB_TOKEN                     │
         └────────── creates branch ──────────┘
                     uploads bundle
                     opens PR
```

---

## Step 1: Create Fine-Grained Personal Access Token

Fine-grained PATs provide minimal permissions — better than classic tokens.

### 1.1 Generate Token

1. Go to https://github.com/settings/tokens?type=beta
2. Click **Generate new token**
3. Configure:

| Field | Value |
|-------|-------|
| **Token name** | `docs-hub-publisher` |
| **Expiration** | 90 days (max recommended) |
| **Resource owner** | `Greggnogg-personal` |
| **Repository access** | Select **Only select repositories** → `docs-hub-poc` |

### 1.2 Required Permissions

| Permission | Access | Why |
|------------|--------|-----|
| **Contents** | Read and write | Create branch, upload bundle file |
| **Pull requests** | Read and write | Create PR |
| **Metadata** | Read | Required for API access |

### 1.3 Copy the Token

Copy the token immediately — it won't be shown again. Format: `github_pat_XXX...`

---

## Step 2: Configure Repository Secret

### In netbox-docs-publisher repo:

1. Go to: https://github.com/Greggnogg-personal/netbox-docs-publisher/settings/secrets/actions
2. Click **New repository secret**
3. Configure:

| Field | Value |
|-------|-------|
| **Name** | `DOCS_HUB_TOKEN` |
| **Secret** | Paste your `github_pat_XXX...` token |

4. Click **Add secret**

---

## Step 3: Configure .docs-publisher.yaml

Ensure your config points to the correct target:

```yaml
# .docs-publisher.yaml
product:
  name: "NetBox Docs Publisher"
  slug: "netbox-docs-publisher"

versioning:
  version: "1.0.0"

paths:
  docs_root: "docs"

push:
  mode: "manual"  # Start with manual for testing
  target:
    owner: "Greggnogg-personal"
    repo: "docs-hub-poc"
```

---

## Step 4: Verify docs-hub-poc Workflow

Ensure the ingest workflow is present and correct:

```bash
# In docs-hub-poc
cat .github/workflows/process-incoming.yml
```

The workflow should trigger on:
- `pull_request` with paths `incoming/**/*.zip`
- `workflow_dispatch` for manual testing

---

## Step 5: Run E2E Test

### Option A: GitHub Actions (Production)

Trigger via workflow dispatch:

1. Go to: https://github.com/Greggnogg-personal/netbox-docs-publisher/actions/workflows/publish-docs.yml
2. Click **Run workflow**
3. Options:
   - `force_push: true` — Skip change detection
   - `dry_run: false` — Actually create PR

### Option B: Local Test (with `act`)

```bash
# From netbox-docs-publisher root
act workflow_dispatch \
  -j publish-docs \
  -s DOCS_HUB_TOKEN="github_pat_XXX..." \
  --input force_push=true \
  --input dry_run=false
```

---

## Step 6: Monitor & Validate

### 6.1 Watch the Source Workflow

1. Go to https://github.com/Greggnogg-personal/netbox-docs-publisher/actions
2. Find the latest "Publish Documentation" run
3. Check each step:
   - ✅ Validate configuration
   - ✅ Create docs bundle
   - ✅ Create PR in docs-hub

### 6.2 Check the Created PR

1. Go to https://github.com/Greggnogg-personal/docs-hub-poc/pulls
2. Find PR titled `docs: NetBox Docs Publisher v1.0.0 (abc1234)`
3. Verify:
   - Bundle file in `incoming/{slug}/{slug}-v{version}-{sha}.zip`
   - PR body shows source repo and SHA

### 6.3 Watch the Ingest Workflow

1. The PR triggers `process-incoming.yml`
2. Check Actions: https://github.com/Greggnogg-personal/docs-hub-poc/actions
3. Verify:
   - ✅ Bundle found in PR
   - ✅ Manifest validated
   - ✅ Docs extracted to `site/{slug}/{version}/`
   - ✅ Smoke tests pass

---

## Troubleshooting

### Token Permission Errors

```
Error: Resource not accessible by integration
```

**Fix**: Ensure the PAT has `contents: write` and `pull_requests: write` on `docs-hub-poc`.

### Bundle Not Found in PR

```
No bundle found in PR changes
```

**Fix**: Ensure the PR modifies files in `incoming/**/*.zip`. Check the git diff.

### Manifest Validation Failed

```
Missing required key: product
```

**Fix**: Ensure `docs_publisher.py bundle` creates a valid manifest. Run locally:

```bash
python scripts/docs_publisher.py bundle --dry-run
python scripts/docs_publisher.py bundle -o test.zip
unzip -l test.zip  # Check manifest.json exists
```

---

## Security Best Practices

### Token Hygiene

| Practice | Recommendation |
|----------|----------------|
| **Expiration** | 90 days max, rotate quarterly |
| **Scope** | Fine-grained PAT, single repo only |
| **Storage** | GitHub Secrets only, never in code |
| **Audit** | Review token usage in GitHub settings |

### Workflow Security

- Use `permissions:` to limit GITHUB_TOKEN scope
- Pin actions to SHA: `actions/checkout@8ade135...`
- Avoid `pull_request_target` (security risk)

### Monitoring

1. Enable GitHub Actions notifications for failures
2. Set branch protection on `main` in docs-hub-poc
3. Review PRs before merging (human in the loop)

---

## Quick Validation Checklist

```bash
[ ] PAT created with correct permissions
[ ] Secret DOCS_HUB_TOKEN added to netbox-docs-publisher
[ ] .docs-publisher.yaml has correct target owner/repo
[ ] process-incoming.yml exists in docs-hub-poc
[ ] Workflow dispatch runs successfully
[ ] PR created in docs-hub-poc
[ ] Ingest workflow validates and extracts bundle
[ ] site/{slug}/{version}/docs/ contains files
```
