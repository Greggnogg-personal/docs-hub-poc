# Docs Publisher Tool — Proposal & Integration Guide

> **Status**: Draft Proposal  
> **Date**: February 20, 2026  
> **Purpose**: Standardized, self-service documentation publishing across NetBox submodules

---

## Prerequisites

Before integrating the Docs Publisher, ensure the following are in place:

### Repository Requirements

| Requirement | Details |
|-------------|----------|
| **GitHub repository** | Each product has its own repository |
| **Documentation folder** | `docs/` directory at repo root (configurable) |
| **Branch protection** | Recommended on `main` to prevent accidental publishes |

### Access & Permissions

| Requirement | Details |
|-------------|----------|
| **`DOCS_HUB_TOKEN` secret** | Fine-grained PAT with `Contents: read/write` and `Pull requests: read/write` scopes on the docs-hub repo |
| **Workflow permissions** | Repository must allow GitHub Actions with `contents: write` permission |
| **Docs hub access** | Token must have access to `netboxlabs/docs-hub-poc` (or test target) |

### Token Setup

1. Go to **GitHub Settings** → **Developer settings** → **Personal access tokens** → **Fine-grained tokens**
2. Create token with:
   - **Repository access**: Select `netboxlabs/docs-hub-poc`
   - **Permissions**: `Contents: Read and write`, `Pull requests: Read and write`
3. Add token as repository secret named `DOCS_HUB_TOKEN`

---

## Overview

The **Docs Publisher** is a lightweight, configuration-driven tool that enables development teams to manage, version, and publish their documentation to the central docs hub with minimal setup. Each team maintains full ownership of their docs while conforming to a shared standard that ensures seamless integration.

### Key Principles

| Principle | Description |
|-----------|-------------|
| **Self-service** | Teams own their docs lifecycle — no central team bottleneck |
| **Config-driven** | All behavior controlled via a single YAML file |
| **Smart push** | Only publish changed content (git diff against last published tag) |
| **Minimal code** | Copy template workflow + edit config = done |
| **Versioned** | Built-in support for semantic versioning, display labels, and release channels |
| **One repo = One product** | Each repository publishes documentation for a single product |

### Design Constraint: Single Product Per Repository

> **Important**: Each repository publishes documentation for exactly **one product**.

This keeps the configuration simple and avoids complexity:

- ✅ One `.docs-publisher.yaml` per repo
- ✅ One `product.slug` — maps directly to docs URL path
- ✅ One version track per repo
- ❌ No multi-product configs
- ❌ No shared docs across products in same repo

If you have a **workspace with multiple repos**, each repo manages its own documentation independently with its own config file.

---

## Architecture

### Flow Diagram

```mermaid
flowchart TD
    subgraph repo["Product Repository"]
        config[".docs-publisher.yaml"]
        docs["docs/"]
        workflow["publish-docs.yml"]
    end

    subgraph trigger["Trigger"]
        push["Push to main"]
        manual["Manual dispatch"]
    end

    subgraph pipeline["Publish Pipeline"]
        load["1. Load config"]
        validate["2. Validate schema"]
        detect["3. Detect changes\n(git diff vs tag)"]
        decision{"Changes found\nOR force_push?"}
        bundle["4. Bundle docs"]
        stamp["5. Stamp version + SHA"]
        pr["6. Create PR in docs-hub"]
        tag["7. Tag: docs-published-v*"]
        skip["Skip publish"]
    end

    subgraph hub["Docs Hub"]
        incoming["incoming/"]
        ingest["Auto-ingest workflow"]
        content["content/{slug}/v{version}/"]
        site["Unified docs site"]
    end

    push --> load
    manual --> load
    config --> load
    docs --> bundle
    
    load --> validate
    validate --> detect
    detect --> decision
    decision -->|Yes| bundle
    decision -->|No| skip
    bundle --> stamp
    stamp --> pr
    pr --> tag
    pr --> incoming
    incoming --> ingest
    ingest --> content
    content --> site

    style repo fill:#e1f5fe
    style hub fill:#e8f5e9
    style pipeline fill:#fff3e0
```

### Component Overview

| Component | Location | Purpose |
|-----------|----------|----------|
| **Config** | `.docs-publisher.yaml` | Versioning, paths, push rules |
| **Source** | `docs/` | Documentation content |
| **Workflow** | `.github/workflows/publish-docs.yml` | CI/CD automation |
| **Docs Hub** | `netboxlabs/docs-hub-poc` | Central aggregation & hosting |

---

## Configuration File

Each submodule repository includes a **`.docs-publisher.yaml`** file at the repository root. This file is separate from any product configuration (`docs.config.json`, `pyproject.toml`, etc.) to maintain clear separation of concerns.

### Full Configuration Reference

```yaml
# .docs-publisher.yaml
# Documentation Publisher Configuration
# Schema version for forward compatibility
schema_version: "1.0"

# ──────────────────────────────────────────────────────────────────────
# PRODUCT METADATA
# ──────────────────────────────────────────────────────────────────────
product:
  # Display name shown in docs site navigation
  name: "NetBox Enterprise"
  
  # URL-safe identifier — used for routing (e.g., docs.netboxlabs.com/{slug}/)
  slug: "netbox-enterprise"
  
  # Owning team (for notifications, PR assignments)
  team: "netbox-core"
  
  # Optional: link to product repo for "Edit on GitHub" links
  repo_url: "https://github.com/netboxlabs/netbox-enterprise"

# ──────────────────────────────────────────────────────────────────────
# VERSIONING
# ──────────────────────────────────────────────────────────────────────
versioning:
  # Current version (semver recommended)
  version: "2.1.0"
  
  # Human-readable label shown in version selector dropdown
  display_label: "v2.1 (February 2026)"
  
  # Versioning strategy: semver | date | custom
  # - semver: expects version like "1.2.3"
  # - date: expects version like "2026.02" or "2026-02-20"
  # - custom: any string, no validation
  strategy: semver
  
  # Optional: mark this version as latest/stable/beta
  channel: stable  # stable | beta | rc | deprecated
  
  # Optional: keep N previous versions accessible (null = keep all)
  retain_versions: 5

# ──────────────────────────────────────────────────────────────────────
# CONTENT PATHS
# ──────────────────────────────────────────────────────────────────────
paths:
  # Root directory containing documentation
  root: "docs/"
  
  # Files/patterns to include in bundle (glob patterns)
  include:
    - "**/*.md"
    - "**/*.mdx"
    - "**/*.png"
    - "**/*.jpg"
    - "**/*.svg"
    - "**/images/**"
    - "**/assets/**"
  
  # Files/patterns to exclude (processed after include)
  exclude:
    - "drafts/**"
    - "internal/**"
    - "**/WIP-*"
    - "**/.DS_Store"
    - "**/node_modules/**"

# ──────────────────────────────────────────────────────────────────────
# PUSH BEHAVIOR
# ──────────────────────────────────────────────────────────────────────
push:
  # Push mode determines when docs are published
  # - auto: publish on any docs change to trigger branches
  # - manual: only publish when force_push input is true
  # - hybrid: auto for patch versions, require manual for major/minor bumps
  mode: auto
  
  # Branches that trigger auto-publish (when mode is auto or hybrid)
  triggers:
    - main
    - master
    - "release/*"
  
  # Target docs hub repository
  target:
    owner: "netboxlabs"
    repo: "docs-hub-poc"
    # Branch pattern for PRs (supports {version}, {sha}, {product})
    branch_pattern: "docs/{product}-v{version}-{sha}"

# ──────────────────────────────────────────────────────────────────────
# CHANGE DETECTION
# ──────────────────────────────────────────────────────────────────────
change_detection:
  # Enable smart push (only publish when content changed)
  enabled: true
  
  # Comparison strategy
  # - git-diff: compare against baseline tag/ref
  # - hash: store file hashes, compare on each run
  # - always: skip detection, always push
  strategy: git-diff
  
  # Baseline for comparison (when strategy is git-diff)
  # - last_pushed: compare against most recent docs-published-* tag
  # - tag:{pattern}: compare against specific tag pattern
  # - commit:{sha}: compare against specific commit
  baseline: last_pushed
  
  # Create tag after successful publish (for baseline tracking)
  tag_on_publish: true
  tag_pattern: "docs-published-v{version}-{sha}"

# ──────────────────────────────────────────────────────────────────────
# LABELS & METADATA
# ──────────────────────────────────────────────────────────────────────
labels:
  # Labels for filtering/categorization in docs hub
  - stable
  - enterprise
  
# Custom metadata passed to docs hub (useful for rendering)
metadata:
  # Show version selector in docs site
  show_version_selector: true
  # Default page when navigating to product docs
  landing_page: "index.md"
  # Navigation order hint (lower = earlier)
  nav_order: 10

# ──────────────────────────────────────────────────────────────────────
# NOTIFICATIONS (Optional)
# ──────────────────────────────────────────────────────────────────────
notifications:
  # Slack webhook for publish notifications
  slack_webhook_secret: "DOCS_SLACK_WEBHOOK"  # secret name, not value
  
  # GitHub team to assign PR reviews
  pr_reviewers:
    - "@netboxlabs/docs-team"
```

### Minimal Configuration (Quick Start)

For teams that want sensible defaults:

```yaml
# .docs-publisher.yaml — Minimal Example
schema_version: "1.0"

product:
  name: "My Product"
  slug: "my-product"

versioning:
  version: "1.0.0"
  display_label: "v1.0"

# All other settings use defaults:
# - paths.root: "docs/"
# - push.mode: "auto"
# - change_detection.enabled: true
# - change_detection.strategy: "git-diff"
```

---

## Integration Steps

### For Development Teams (5-Minute Setup)

#### Step 1: Copy Template Files

```bash
# From the netbox-docs-publisher template repo or shared location
curl -O https://raw.githubusercontent.com/netboxlabs/netbox-docs-publisher/main/templates/.docs-publisher.yaml
curl -O https://raw.githubusercontent.com/netboxlabs/netbox-docs-publisher/main/templates/.github/workflows/publish-docs.yml
mkdir -p .github/workflows
mv publish-docs.yml .github/workflows/
```

Or copy from a sibling repo that already has it configured.

#### Step 2: Edit Configuration

Open `.docs-publisher.yaml` and update:

```yaml
product:
  name: "Your Product Name"      # ← Change this
  slug: "your-product-slug"      # ← Change this (URL-safe)

versioning:
  version: "1.0.0"               # ← Set your version
  display_label: "v1.0"          # ← Human-readable label
```

#### Step 3: Commit and Push

```bash
git add .docs-publisher.yaml .github/workflows/publish-docs.yml
git commit -m "chore: add docs publisher integration"
git push origin main
```

The workflow will automatically trigger on docs changes to `main`.

#### Step 4: Verify

1. Make a change to any file in `docs/`
2. Commit and push to `main`
3. Check GitHub Actions — workflow should run
4. Check `netboxlabs/docs-hub-poc` for incoming PR

---

## Workflow Usage

### Automatic Publishing (Default)

When `push.mode: auto`, the workflow triggers automatically on:
- Push to configured branches (`main`, `master`, `release/*`)
- When files in `paths.root` (default: `docs/`) are modified

### Manual Publishing

Trigger manually via GitHub Actions UI:

1. Go to **Actions** → **Publish Docs**
2. Click **Run workflow**
3. Options:
   - `force_push`: Publish even if no changes detected
   - `dry_run`: Validate config and bundle without pushing

### Force Push (Override Change Detection)

```bash
# Via GitHub CLI
gh workflow run publish-docs.yml -f force_push=true
```

### Version Bump Workflow

When releasing a new version:

1. Update `.docs-publisher.yaml`:
   ```yaml
   versioning:
     version: "2.0.0"           # ← Bump version
     display_label: "v2.0"      # ← Update label
   ```

2. Commit with your release:
   ```bash
   git add .docs-publisher.yaml
   git commit -m "docs: bump to v2.0.0"
   git push origin main
   ```

3. Workflow automatically publishes to docs hub with new version

---

## Change Detection Behavior

### How It Works

1. **On each run**, the workflow looks for the most recent `docs-published-*` tag
2. **Compares** current `docs/` content against that tag using `git diff`
3. **If changes detected** → creates bundle and publishes
4. **If no changes** → skips publish (unless `force_push: true`)
5. **After successful publish** → creates new tag: `docs-published-v{version}-{sha}`

### Tag Format

```
docs-published-v2.1.0-abc1234
│               │     │
│               │     └── Short commit SHA
│               └──────── Version from config
└──────────────────────── Prefix for identification
```

### Resetting Baseline

To republish all docs (reset change detection):

```bash
# Delete all docs-published tags
git tag -l "docs-published-*" | xargs git tag -d
git push origin --delete $(git tag -l "docs-published-*")

# Trigger workflow with force_push
gh workflow run publish-docs.yml -f force_push=true
```

---

## Bundle Format

The published bundle (`docs-bundle-{sha}.zip`) contains:

```
docs-bundle-abc1234.zip
├── manifest.json           ← Metadata from config
├── content/
│   ├── index.md
│   ├── getting-started.md
│   ├── api/
│   │   └── reference.md
│   └── images/
│       └── diagram.png
└── .docs-publisher.yaml    ← Copy of config for docs hub
```

### manifest.json

```json
{
  "schema_version": "1.0",
  "product": {
    "name": "NetBox Enterprise",
    "slug": "netbox-enterprise"
  },
  "versioning": {
    "version": "2.1.0",
    "display_label": "v2.1 (February 2026)",
    "channel": "stable"
  },
  "source": {
    "repo": "netboxlabs/netbox-enterprise",
    "commit": "abc1234def5678",
    "branch": "main",
    "published_at": "2026-02-20T14:30:00Z"
  },
  "labels": ["stable", "enterprise"]
}
```

---

## FAQ

### Q: What if I don't want automatic publishing?

Set `push.mode: manual` in your config:

```yaml
push:
  mode: manual
```

Then trigger manually via GitHub Actions UI or CLI with `force_push: true`.

### Q: Can I publish multiple versions simultaneously?

Yes — each version gets its own path in the docs hub:

```
content/netbox-enterprise/v2.1/
content/netbox-enterprise/v2.0/
content/netbox-enterprise/v1.9/
```

Set `versioning.retain_versions` to control how many are kept.

### Q: What happens if config validation fails?

The workflow fails fast with a clear error message before any publish attempt:

```
❌ Config validation failed:
   - versioning.version: "abc" is not valid semver
   - product.slug: contains invalid characters (must be URL-safe)
```

### Q: How do I exclude certain files from publishing?

Use the `paths.exclude` array:

```yaml
paths:
  exclude:
    - "internal/**"       # Internal docs
    - "drafts/**"         # Work in progress
    - "**/TODO.md"        # Planning files
```

### Q: Can I test locally before pushing?

Yes — use the CLI tool:

```bash
# Validate config
python scripts/docs_publisher.py validate

# Dry-run bundle creation
python scripts/docs_publisher.py bundle --dry-run

# Create bundle locally
python scripts/docs_publisher.py bundle --output ./test-bundle.zip
```

---

## Rollback & Hotfix

### Scenario: Bad Publish Needs Reverting

If a publish introduces broken content or incorrect docs:

#### Option 1: Revert Commit (Recommended)

```bash
# Revert the docs change commit
git revert <commit-sha>
git push origin main

# Workflow auto-triggers and publishes corrected version
```

#### Option 2: Force Re-publish Previous Version

```bash
# Checkout previous good state
git checkout <good-commit-sha> -- docs/

# Bump patch version in config
# Edit .docs-publisher.yaml: version: "2.1.1"

git add .
git commit -m "docs: hotfix - revert to previous content"
git push origin main
```

#### Option 3: Manual PR Close + Republish

1. Close the bad PR in `docs-hub-poc` without merging
2. Fix content in source repo
3. Force republish:
   ```bash
   gh workflow run publish-docs.yml -f force_push=true
   ```

### Clearing Published Version from Docs Hub

If a version was merged and needs removal:

1. In `docs-hub-poc`, delete the version folder:
   ```
   content/{product-slug}/v{version}/
   ```
2. Update `versions.json` to remove the entry
3. Commit and deploy

### Preventing Accidental Publishes

- Use `push.mode: manual` for sensitive products
- Enable branch protection on `main`
- Require PR reviews before merge

---

## Support & Feedback

- **Issues**: [netboxlabs/netbox-docs-publisher/issues](https://github.com/netboxlabs/netbox-docs-publisher/issues)
- **Slack**: `#docs-platform`
- **Team**: @netboxlabs/docs-platform

---

## Appendix: Config Schema (JSON Schema)

A JSON Schema is provided for IDE autocompletion and validation:

```bash
# VS Code: add to .vscode/settings.json
{
  "yaml.schemas": {
    "https://raw.githubusercontent.com/netboxlabs/netbox-docs-publisher/main/schema/docs-publisher.schema.json": ".docs-publisher.yaml"
  }
}
```
