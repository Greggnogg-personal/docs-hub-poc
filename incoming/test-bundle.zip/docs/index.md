# Docs Publisher — Developer Documentation

Welcome to the **Docs Publisher** documentation. This tooling enables standardized, self-service documentation publishing across NetBox product repositories.

## Quick Start

1. Copy `.docs-publisher.yaml` to your repo root
2. Edit product name, slug, and version
3. Add the workflow template to `.github/workflows/`
4. Push to `main` — docs are automatically published

## Documentation

| Guide | Description |
|-------|-------------|
| [Integration Proposal](DOCS_PUBLISHER_PROPOSAL.md) | Full architecture, configuration reference, and integration steps |
| [Local Testing with Act](ACT.md) | Run workflows locally using `act` |
| [E2E Local Ingest](E2E_LOCAL_INGEST.md) | End-to-end testing guide |

## API & Advanced

- [API Endpoints](api/endpoints.md)
- [Getting Started](guides/intro.md)
- [Advanced Configuration](guides/advanced.md)

---

> **Version**: 1.0.0 | **Last Updated**: February 20, 2026
