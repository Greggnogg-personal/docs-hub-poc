# Welcome to the Test NetBox Docs

This is a minimal test documentation set used to validate the new ingestion pipeline.

Test ingestion run at `13:30 - 29-01-2026'