# Running workflows locally with `act` ⚙️

This project includes a minimal `act` configuration and an example event so you can run workflows locally.

Files added:

- `.actrc` — maps `ubuntu-latest` to `nektos/act-environments-ubuntu:18.04` image.
- `.github/act/publish-docs.event.json` — event payload for `workflow_dispatch` with `push: false` (safe local test).
- `.github/act/publish-docs.simulate.event.json` — event payload for `workflow_dispatch` with `local_simulate: true` (copies bundle to `./local-docs-hub`).
- `scripts/run_act_publish_docs.sh` / `act` CLI — helper to run the `publish-docs` job (shell or direct `act` recommended).
- `scripts/run_local_simulate.py` — Host-side Python helper that performs the local-simulate steps without `act`/Docker (useful when Docker is unavailable).
- `scripts/verify_simulate.py` — Cross-platform Python verifier for simulation outputs.

Quick steps (Shell / cross-platform):

1. Ensure Docker is running and you have `act` installed (https://github.com/nektos/act).
2. From the repository root run:
   - For a *safe* test (no push): use `act` (see examples below)
   - For a *full simulate* of push/PR steps without contacting GitHub: `act -j publish-docs -e .github/act/publish-docs.simulate.event.json` (this will copy the bundle into `./local-docs-hub`, create a branch `docs/update-<sha>` and write a `simulated-pr-<sha>.txt` file on the runner; the simulated PR summary is also printed to the job logs).
   - If Docker or `act` isn't available, use the host-only simulation: `python scripts/run_local_simulate.py` (creates `local-docs-hub` and `simulated-pr-<sha>.txt` directly on the host).

Verification note:
- The `publish-docs` workflow now accepts a `verify` input (default `true`). When `local_simulate` and `verify` are both `true` the workflow runs `scripts/verify_simulate.py` on the runner to assert outputs and will fail the job if verification fails.
- The workflow also supports an optional `matrix_verify` input (default `false`) to run the same simulation and verification across a matrix of runners (`ubuntu-latest` and `windows-latest`) for extra confidence.
- To toggle verification when running with `act` edit the event JSON and set `"verify": false` or `"verify": true` as needed (e.g., `.github/act/publish-docs.simulate.event.json`).
3. The workflow will create `bundle/docs-bundle.zip`. Because `push` is `false` the push and PR steps are skipped unless `local_simulate` or `push` is enabled.

To test PR/push steps locally you must provide `DOCS_HUB_TOKEN` as a secret and run the event with `push: true`. Example (Linux/macOS):

- `act -j publish-docs -e .github/act/publish-docs.event.json -s DOCS_HUB_TOKEN=ghp_...` (or set it in `.secrets` for `act`).

Notes:
- The image `nektos/act-environments-ubuntu:20.04` used here includes common tooling; if you hit missing tools (e.g., `zip`) we can change the image or add a small step to install required packages at runtime.

---

## Verification checklist ✅

After running the simulation, perform these checks:

1. Ensure Docker is running: `docker version` shows Server info.
2. Run the simulation (with `act`) or use the host-side Python simulate helper:
   - With `act`: `act -j publish-docs -e .github/act/publish-docs.simulate.event.json` or `act -j publish-docs -e .github/act/publish-docs.event.json`
   - Host-only (no Docker/act): `python scripts/run_local_simulate.py` (creates `local-docs-hub` and `simulated-pr-<sha>.txt` on the host)
3. Confirm the docs bundle exists: `ls bundle/docs-bundle.zip` or `python -c "import zipfile; zipfile.ZipFile('bundle/docs-bundle.zip').testzip()"`.
4. Inspect `local-docs-hub`:
   - Look for branch folder `docs/update-<sha>` or run `git -C local-docs-hub branch --list`.
   - Verify `bundle/docs-bundle.zip` is present in the branch commit.
   - Confirm `simulated-pr-<sha>.txt` exists at the repo root or branch folder.
5. Optional: there's a cross-platform verification script `scripts/verify_simulate.py` that exits non-zero if checks fail. Example usage:

```bash
python scripts/verify_simulate.py --local-hub ./local-docs-hub
```

The script checks for `bundle/docs-bundle.zip`, the existence of the `local-docs-hub`, and the presence of `simulated-pr-*.txt` files.

---

## Next steps 🔧

- Add `scripts/verify_simulate.py` to assert outputs and integrate into local test checklist.
- Consider an artifact persistence approach (pre-mounted host path) so artifacts survive `act` container lifecycle.
- When ready, plan an integration test with a disposable docs-hub repo and a token under strict guardrails.

---
