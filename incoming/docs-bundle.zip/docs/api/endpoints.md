# API Endpoints

This file simulates API documentation for the ingestion POC.
