# Advanced Guide

This guide contains more advanced examples for testing nested folder ingestion.
