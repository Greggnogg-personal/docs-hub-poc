## Local end-to-end ingest helper (e2e_local_ingest)

Short helper to test the docs push -> docs-hub ingest flow locally using `act`.

Prerequisites
- Python 3
- git
- act (https://github.com/nektos/act)
- Docker daemon running

Quick usage
- Run the helper from the `docs-hub` repository root:

```sh
python scripts/e2e_local_ingest.py --skeleton-path ../skeleton-netbox-submodule
```

Use `--verify-regex` to search `act` logs for a success pattern or `--verify-path` to assert filesystem results.

Notes
- The helper creates a temporary git branch and commits the bundle file; use `--keep-branch` to preserve it for debugging.
- Tests are provided but marked as integration (skipped by default in lightweight CI).
