# Welcome to the Test NetBox Docs

This is a minimal test documentation set used to validate the new ingestion pipeline.

**E2E Test - Feb 5, 2026**: Testing cross-repo PR creation with auto-bundle upload.

Test ingestion run at `13:30 - 29-01-2026'